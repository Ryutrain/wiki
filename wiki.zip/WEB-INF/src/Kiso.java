public class Kiso{
	private String kyoku;
	private int eplus;
	private String carp;
	
	
}

	